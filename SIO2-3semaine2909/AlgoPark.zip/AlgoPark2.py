# NE PAS TOUCHER
groups = [3, 1, 1, 1, 1, 4, 2, 4, 3, 2, 4, 3, 2]
# NE PAS TOUCHER

NACELLE_MAX = 4

def embark():
    nacelle_passengers = 0
    nacelles = 0
    last_nacelle = 0

    for group in groups:
        if nacelle_passengers + group <= NACELLE_MAX:
            nacelle_passengers += group
        else:
            nacelles += 1
            last_nacelle = nacelle_passengers
            nacelle_passengers = group

    # Après la boucle, il faut compter la dernière nacelle
    nacelles += 1
    last_nacelle = nacelle_passengers

    return f"{nacelles}_{last_nacelle}"  # Format "X_Y" sans espaces

resultat = embark()
print(resultat)  # Affiche "7_3"

