const groups = [3, 3, 1, 3, 4, 4, 1, 4, 3, 1, 4, 4, 3];
//const groups = [2, 3, 1, 4, 4, 1, 4];

const NACELLE_MAX = 4;
let last_nacelle = 0;

function embark(groups) {
    let nacelle_passengers = 0;
    let nacelles = 0;

    groups.forEach(group => {
        if (nacelle_passengers + group <= NACELLE_MAX) {
            nacelle_passengers += group;
        } else {
            nacelles++;
            last_nacelle = nacelle_passengers;
            nacelle_passengers = group;
        }
    });

    // Après la boucle, il faut compter la dernière nacelle
    nacelles++;
    last_nacelle = nacelle_passengers;

    console.log(`${nacelles}_${last_nacelle}`);
}

embark(groups);