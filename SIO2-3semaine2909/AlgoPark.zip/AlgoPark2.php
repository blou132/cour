<?php
// https://tainix.fr/challenge/AlgoPark-2-la-grande-Roue

//$groups = [3, 3, 1, 3, 4, 4, 1, 4, 3, 1, 4, 4, 3];
$groups = [2, 3, 1, 4, 4, 1, 4];

const NACELLE_MAX = 4;

$last_nacelle = 0;

    
function embark($groups)
{
    $nacelle_passengers = 0;
    $nacelles = 0;
    
    foreach($groups as $group)
    {
        if($nacelle_passengers + $group <= NACELLE_MAX)
            $nacelle_passengers += $group;
        else
        {
            $nacelles++;
            $last_nacelle = $nacelle_passengers;
            $nacelle_passengers = $group;
        }
    }
    // Après la boucle, il faut compter la dernière nacelle
    $nacelles++;
    $last_nacelle = $nacelle_passengers;
    echo $nacelles . "_" . $last_nacelle;
}

embark($groups);