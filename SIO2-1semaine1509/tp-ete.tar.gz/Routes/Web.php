<?php

namespace App\Routes;

use App\Controllers\HtmlController;
/**
* Simple example of implementing a route class and declaring __construct
* , then using the navigator method to initialize the menu.
*/
class Web
{
    function __construct()
    {
        $html = new HtmlController();
        
        $html->tagOpen("ul id=\"navigation\"");
        $html->URLlink("/index.php", "Accueil"); 
        $html->URLlink("/Views/championnat.lame.php", "Championnat"); 
        $html->URLlink("/Views/joueur.lame.php", "Joueur"); 
        $html->URLlink("/Views/equipe.lame.php", "Equipe");
        $html->URLlink("/Views/equipe_joueur.lame.php", "Equipe + Joueur");
        $html->tagClose("ul"); 
    } 
}