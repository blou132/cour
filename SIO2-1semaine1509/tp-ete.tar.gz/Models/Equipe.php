<?php

namespace App\Models;

define("EQUIPES", "equipes");

/**
 * Classe Equipe
 */ 
class Equipe extends Model
{

    /**
     * Attribut Nom de l'Equipe
     */ 
    private $nom;

    /**
     * Attribut Ville de l'Equipe
     */ 
    private $ville;

    /**
     * Attribut Stade de l'Equipe
     */ 
    private $stade;

    /**
     * Attribut Identifiant Championnat de l'Equipe
     */ 
    private $id_championnat;

    /**
     * Attribut Blason de l'Equipe
     */ 
    private $blason;


    /**
     * Constructeur de l'Equipe
     */ 
    public function __construct()
    {

    }

    /**
     * Afficher la liste des Equipes
     */ 
    public function list()
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        $this->all(EQUIPES, $attributes);
    }

    /**
     * Mettre à disposition les Equipes dans une array
     */ 
    public function pack():array
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        return $this->packAll(EQUIPES, $attributes);
    }

    /**
     * Insérer une Equipe
     */ 
    public function insertEquipe($records)
    {
        $attributes = get_class_vars(get_class($this));
        $this->insert(EQUIPES, $attributes, $records);
    }

    /**
     * Chercher une Equipe
     */ 
    public function findEquipe($column, $criteria)
    {
        $result = $this->find(EQUIPES, $column, $criteria);
        return $result;
    }

    /**
     * Modifier le champ d'une Equipe
     */ 
    public function modifyEquipe($column, $change, $columnCriteria, $criteria)
    {
        $this->update(EQUIPES, $column, $change, $columnCriteria, $criteria);

        //print_r($result);
    }

    /**
     * Supprimer une Equipe
     */ 
    public function deleteEquipe($column, $criteria)
    {
        $this->delete(EQUIPES, $column, $criteria);
    }

    /**
     * Obtenir la valeur du Nom
     */ 
	public function getNom(): string
	{
		return $this->nom;
	}

    /**
     * Obtenir la valeur de la Ville
     */ 
	public function getVille(): string
	{
		return $this->ville;
	}

    /**
     * Obtenir la valeur du Stade
     */ 
	public function getStade(): string
	{
		return $this->stade;
	}

    /**
     * Obtenir la valeur de l'Identifiant Championnat 
     */ 
	public function getIDChampionnat(): int
	{
		return $this->id_championnat;
	}

    /**
     * Obtenir la valeur du Blason
     */ 
	public function getBlason(): string
	{
		return $this->blason;
	}

    /**
     * Configurer la valeur du Nom
     */ 
	public function setNom($nom): void
	{
		$this->nom = $nom;
	}

    /**
     * Configurer la valeur du Ville
     */ 
	public function setVille($ville): void
	{
		$this->ville = $ville;
	}

    /**
     * Configurer la valeur du Stade
     */ 
	public function setStade($stade): void
	{
		$this->stade = $stade;
	}

    /**
     * Configurer la valeur de l'Identifiant championnat
     */ 
	public function setIDChampionnat($id_championnat): void
	{
		$this->id_championnat = $id_championnat;
	}

    /**
     * Configurer la valeur de la Description
     */ 
	public function setBlason($blason): void
	{
		$this->blason = $blason;
	}
}