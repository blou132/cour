<?php

namespace App\Models;

define("JOUEURS", "joueurs");


/**
 * Classe Article
 */ 
class Joueur extends Model
{

    /**
     * Attribut Position
     */ 
    private $position;

    /**
     * Attribut Numero
     */ 
    private $numero;

    /**
     * Attribut Nom
     */ 
    private $nom;

    /**
     * Attribut Nationalité
     */ 
    private $nationalite;

    /**
     * Attribut Age
     */ 
    private $age;

    /**
     * Attribut Identifiant de l'Equipe
     */ 
    private $id_equipe;
    
    /**
     * Attribut Photo
     */ 
    private $photo;


    /**
     * Constructeur de Joueur
     */ 
    public function __construct()
    {

    }

    /**
     * Afficher la liste des Joueurs
     */ 
    public function list()
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        $this->all(JOUEURS, $attributes);
    }

    /**
     * Mettre à disposition les Joueurs dans une array
     */ 
    public function pack():array
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        return $this->packAll(JOUEURS, $attributes);
    }

    /**
     * Insérer un Joueur
     */ 
    public function insertJoueur($records)
    {
        $attributes = get_class_vars(get_class($this));
        $this->insert(JOUEURS, $attributes, $records);
    }

    /**
     * Chercher un Joueur
     */ 
    public function findJoueur($column, $criteria)
    {
        $result = $this->find(JOUEURS, $column, $criteria);
        return $result;
    }

    /**
     * Modifier le champ d'un Joueur
     */ 
    public function modifyJoueur($column, $change, $columnCriteria, $criteria)
    {
        $this->update(JOUEURS, $column, $change, $columnCriteria, $criteria);

        //print_r($result);
    }

    /**
     * Supprimer un Joueur
     */ 
    public function deleteJoueur($column, $criteria)
    {
        $this->delete(JOUEURS, $column, $criteria);
    }

    /**
     * Obtenir la valeur de la Position
     */ 
	public function getPosition(): string
	{
		return $this->position;
	}

    /**
     * Obtenir la valeur du Numero
     */ 
	public function getNumero(): int
	{
		return $this->numero;
	}

    /**
     * Obtenir la valeur du Nom
     */ 
	public function getNom(): string
	{
		return $this->nom;
	}

    /**
     * Obtenir la valeur de la Nationalité
     */ 
	public function getNationalite(): string
	{
		return $this->nationalite;
	}

    /**
     * Obtenir la valeur de l'Age
     */ 
	public function getAge(): int
	{
		return $this->age;
	}

    /**
     * Obtenir la valeur de la Photo
     */ 
	public function getPhoto(): string
	{
		return $this->photo;
	}

    /**
     * Obtenir la valeur de l'Identifiant d'Equipe
     */ 
	public function getIDEquipe(): int
	{
		return $this->id_equipe;
	}

    /**
     * Configurer la valeur de la Position
     */ 
	public function setPosition($position): void
	{
		$this->position = $position;
	}

    /**
     * Configurer la valeur du Numero
     */ 
	public function setNumero($numero): void
	{
		$this->numero = $numero;
	}

    /**
     * Configurer la valeur du Nom
     */ 
	public function setNom($nom): void
	{
		$this->nom = $nom;
	}

    /**
     * Configurer la valeur de la Nationalité
     */ 
	public function setNationalite($nationalite): void
	{
		$this->nationalite = $nationalite;
	}

    /**
     * Configurer la valeur de l'Age'
     */ 
	public function setAge($age): void
	{
		$this->age = $age;
	}

    /**
     * Configurer la valeur de la Photo
     */ 
	public function setPhoto($photo): void
	{
		$this->photo = $photo;
	}

   /**
     * Configurer la valeur de l'Identifiant de l'Equipe'
     */ 
	public function setIDEquipe($id_equipe): void
	{
		$this->id_equipe = $id_equipe;
	}
}