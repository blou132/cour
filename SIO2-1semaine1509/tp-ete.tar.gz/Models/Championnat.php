<?php

namespace App\Models;

use App\Database\Database;

define("CHAMPIONNATS", "championnats");


/**
 * Classe Article
 */ 
class Championnat extends Model
{
    /**
     * Attribut Division
     */ 
    private $division;

    /**
     * Attribut Annee
     */ 
    private $annee;

    /**
     * Attribut Pays
     */ 
    private $pays;

    /**
     * Attribut Genre
     */ 
    private $genre;

    /**
     * Attribut Professionnalisation
     */ 
    private $professionnalisation;

    /**
     * Attribut Photo
     */ 
    private $blason;


    /**
     * Constructeur de la Championnat'
     */ 
    public function __construct()
    {

    }

    /**
     * Afficher la liste des championnats
     */ 
    public function list()
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        $this->all(CHAMPIONNATS, $attributes);
    }

    /**
     * Mettre à disposition les Championnats dans une array
     */ 
    public function pack():array
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        return $this->packAll(CHAMPIONNATS, $attributes);
    }

    /**
     * Insérer une Championnat
     */ 
    public function insertChampionnat($records)
    {
        $attributes = get_class_vars(get_class($this));
        $this->insert(CHAMPIONNATS, $attributes, $records);
    }

    /**
     * Chercher une Championnat
     */ 
    public function findChampionnat($column, $criteria)
    {
        $result = $this->find(CHAMPIONNATS, $column, $criteria);
        return $result;
    }

    /**
     * Modifier le champ d'une Championnat
     */ 
    public function modifyChampionnat($column, $change, $columnCriteria, $criteria)
    {
        $this->update(CHAMPIONNATS, $column, $change, $columnCriteria, $criteria);

        //print_r($result);
    }

    /**
     * Supprimer une Championnat
     */ 
    public function deleteChampionnat($column, $criteria)
    {
        $this->delete(CHAMPIONNATS, $column, $criteria);
    }

    /**
     * Obtenir la valeur du Moteur 
     */ 
	public function getDivision(): string
	{
		return $this->division;
	}

    /**
     * Obtenir la valeur de l'Annee
     */ 
	public function getAnnee(): int
	{
		return $this->annee;
	}

    /**
     * Obtenir la valeur du Pays 
     */ 
	public function getPays(): string
	{
		return $this->pays;
	}

    /**
     * Obtenir la valeur du Genre 
     */ 
	public function getGenre(): string
	{
		return $this->genre;
	}

    /**
     * Obtenir la valeur de la Professionnalisation 
     */ 
	public function getProfessionnalisation(): bool
	{
		return $this->professionnalisation;
	}

    /**
     * Obtenir la valeur du Blason
     */ 
	public function getBlason(): string
	{
		return $this->blason;
	}

    /**
     * Configurer la valeur de la Division
     */ 
	public function setDivision($division): void
	{
		$this->division = $division;
	}

    /**
     * Configurer la valeur de l'Annee
     */ 
	public function setAnnee($annee): void
	{
		$this->annee = $annee;
	}

    /**
     * Configurer la valeur du Pays
     */ 
	public function setPays($pays): void
	{
		$this->pays = $pays;
	}

    /**
     * Configurer la valeur du Genre
     */ 
	public function setGenre($genre): void
	{
		$this->genre = $genre;
	}

    /**
     * Configurer la valeur du Professionnalisation
     */ 
	public function setProfessionnalisation($professionnalisation): void
	{
		$this->professionnalisation = $professionnalisation;
	}

    /**
     * Configurer la valeur du Blason
     */ 
	public function setBlason($blason): void
	{
		$this->blason = $blason;
	}
}