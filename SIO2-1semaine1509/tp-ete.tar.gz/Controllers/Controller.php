<?php
namespace App\Controllers;

abstract class Controller 
{


}
