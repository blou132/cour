<?php

namespace App\Controllers;

class ValidationController extends Controller
{

    public function validate(string $name_value): bool
    {
         // define variable to empty value  
         $nameErr = "";
         $valid = false;         
        
         //Input field validation  
        if ($_SERVER["REQUEST_METHOD"] == "POST") {  
              
        //String Validation  
            if (empty($_POST[$name_value])) {  
                 $nameErr = "Une entrée est requise";  
            } else {  
                $validate = $this->input_data($_POST["$name_value"]);  
                    // check if name only contains letters and whitespace. This does not work for some reason: \p{L}\p{Pd} 
                    if (!preg_match("/^[a-zA-Z]|[à-ü]|[À-Ü0-9 .,-]*$/",$validate)) {  
                        $nameErr = "Uniquement les lettres de l'alphabet, les chiffres, les caractères de ponctuation et les espaces sont autorisés";  
                    } 
                    else
                    $valid = true;
            } 
            $this->tagError($nameErr);
            return $valid;
        }    
         return $valid;
   }

    public function validateDecimal(string $name_value): bool
    {
         // define variable to empty value  
         $nameErr = "";
         $valid = false;         
        
         //Input field validation  
        if ($_SERVER["REQUEST_METHOD"] == "POST") {  
              
        //String Validation  
            if (empty($_POST[$name_value])) {  
                $nameErr = "Une entrée est requise";                   
            } else {  
                $validate = $this->input_data($_POST["$name_value"]);  
                    // check if name only contains letters and whitespace. This does not work for some reason: \p{L}\p{Pd} 
                    if (!preg_match("/^[0-9]?[0-9]?(\.[0-9][0-9]?)?*$/",$validate)) {  
                        $nameErr = "Uniquement les valeurs monétaires avec 2 chiffres après la virgule sont autorisés";  
                    } 
                    else
                    $valid = true;
            } 
            $this->tagError($nameErr);
            return $valid;
        }    
        return $valid;
    }

    public function validateDate(string $name_value): bool
    {
         // define variable to empty value  
         $nameErr = "";
         $valid = false;         
        
         //Input field validation  
        if ($_SERVER["REQUEST_METHOD"] == "POST") {  
              
        //String Validation  

            $validate = $this->input_data($_POST["$name_value"]);  
                // check if date only
                if(empty($_POST[$name_value]))
                    $valid = true;
                else if (!preg_match("/^[0-3]?[0-9].[0-3]?[0-9].(?:[0-9]{2})?[0-9]{2}$/",$validate)) {  
                    $nameErr = "Uniquement le format date jj/mm/aaaa est autorisé";  
                }
                else
                $valid = true;

            $this->tagError($nameErr);
            return $valid;
        }    
        return $valid;
    }

    public function validateEmptyOK(string $name_value): bool
    {
         // define variable to empty value  
         $nameErr = "";
         $valid = false;         
        
         //Input field validation  
        if ($_SERVER["REQUEST_METHOD"] == "POST") {  
              
        //String Validation  

            $validate = $this->input_data($_POST["$name_value"]);  
                // check if name only contains letters and whitespace  
                if (!preg_match("/^[a-zA-Z]|[à-ü]|[À-Ü0-9 .,-]*$/",$validate)) {  
                    $nameErr = "Uniquement les lettres de l'alphabet, les chiffres et les espaces sont autorisés";  
                } 
                else
                $valid = true;
             
        $this->tagError($nameErr);
        return $valid;
        }    
        return $valid;
    }
    
    public function validateEmail(string $email): bool
    {
         // define variable to empty value  
         $nameErr = "";
         $valid = false;         
        
         //Input field validation  
        if ($_SERVER["REQUEST_METHOD"] == "POST") {  
              
        //String Validation  
            if (empty($_POST[$email])) {  
                 $nameErr = "Une entrée est requise";  
            } else {  
                $validate = $this->input_data($_POST["$email"]);  
                    // check if email is valid
                    if (!preg_match("/^[^0-9][_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/",$validate)) {  
                        $nameErr = "Votre adresse email est invalide";  
                    } 
                    else
                    $valid = true;
            } 
            $this->tagError($nameErr);
            return $valid;
        }    
        return $valid;
    }

    public function validatePassword(string $password): bool
    {
         // define variable to empty value  
         $nameErr = "";
         $valid = false;         
        
         //Input field validation  
        if ($_SERVER["REQUEST_METHOD"] == "POST") {  
              
        //String Validation  
            if (empty($_POST[$password])) {  
                 $nameErr = "Une entrée est requise";  
            } else {  
                $validate = $this->input_data($_POST["$password"]);  
                    // check if password is valid
                    if (!preg_match("/^(?=(?:\S*\d){2})(?=(?:\S*[A-Za-z]){2})(?=\S*[^A-Za-z0-9])\S{8,}$/",$validate)) {  
                        $nameErr = "Votre mot de passe est invalide, il doit au moins être composé de 8 caractères, contenir une lettre minuscule, une lettre majuscule, un chiffre et un caractère spécial";  
                    } 
                    else
                    $valid = true;
            } 
            $this->tagError($nameErr);
            return $valid;
        }    
        return $valid;
    }

    function input_data($data) {  
        $data = trim($data);  
        $data = stripslashes($data);  
        $data = htmlspecialchars($data);  
        return $data;  
    }

    function tagError(string $nameErr): void
    {
        echo "<span class=\"error\">$nameErr</span>";
    }

    function tagSuccess(string $nameSuccess): void
    {
        echo "<span class=\"success\">$nameSuccess</span>";
    }
}