<?php

namespace App\Controllers;

class HtmlController extends Controller
{
    public function pageTitle(string $title): void
    {
        echo "<title>$title</title>";
    }

    public function tagOpen(string $tag): void
    {
        echo "<$tag>";
    }

    public function tagClose(string $tag): void
    {
        echo "</$tag>";
    }

    public function URLlink(string $path, string $content): void
    {
        echo "<li><a href=\"$path\">$content</a></li>";
    }

    public function tagImage($path, $alt, $width, $height): void
    {
        echo "<img src=\"$path\" alt=\"$alt\" width=\"$width\" height=\"$height\">";
    }
}