<?php

namespace App\Controllers;

class StyleController extends Controller
{
    public function __construct()
    {
        echo "<style>
        html {
            display: flex;
            justify-content: center;
        };
        </style>";

        echo "<style>
        .error{
            color: #FF0001;
        };
        </style>";

        echo "<style>
        .success{
            color: #00FF01;
        };
        </style>";

        echo "<style>
        body{
            background-color:#b5cde5;
        };
        </style>";

        echo "<style>
        form{
            border : 2px solid #000000;
            background-color:#b5cd05;
            width: 355;
            margin-left: auto;
            margin-right: auto;
        };
        </style>";


        echo "<style>
        #navigation li {
            display: inline ;
            margin-right: 5px ;
            color: #fff ;
            background: #0066AA;
            padding: 4px 4px;
        };
        </style>";

        echo "<style>        
        a:visited {
            color: #a9edf9;
        };
        </style>";

        echo "<style>        
        a:link {
            color: #BBCCEE;
        };
        </style>";

        echo "<style>        
        a:hover {
            color: #BB2266;
        };
        </style>";
        echo "<style> 
        table, th, td {
            border:1px solid black;
        };
        </style>";
    }    
}