<?php

namespace App\Controllers;

use \App\Models\Joueur;
use \App\Controllers\ValidationController;

class JoueurController extends Controller
{
    public function create($record): void
    {
        //$record = implode('\', \'', array_values($record));

        $joueur = new Joueur();
        $validation = new ValidationController();

        $joueur->insertJoueur($record);
        $joueur->setPosition($record[0]);
        $joueur->setNumero($record[1]);
        $joueur->setNom($record[2]);
        $joueur->setNationalite($record[3]);
        $joueur->setAge($record[4]);
        $joueur->setIDEquipe(id_equipe: $record[5]);
        $joueur->setPhoto($record[6]);

        $nameSuccess = "New Joueur was created successfully!";
        $validation->tagSuccess($nameSuccess);

    }

    public function read():void
    {
        $joueur = new Joueur();
        $validation = new ValidationController();

        $joueur->list();

        $nameSuccess = "Joueur list was displayed successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function deliverPack():array
    {
        $joueur = new Joueur();
        //$validation = new ValidationController();

        return $joueur->pack();
    }

    /**
     * Chercher une joueur par ID
     */ 
    public function findByID($criteria):array
    {
        $joueur = new Joueur();

        return $joueur->findJoueur('id_joueur', $criteria);
    }

    /**
     * Chercher un joueur par Nom
     */ 
    public function findByType($criteria):array
    {
        $joueur = new Joueur();

        return $joueur->findJoueur('nom', $criteria);
    }

    public function update($column, $change, $columnCriteria, $criteria): void
    {
        $joueur = new Joueur();
        $validation = new ValidationController();

        $joueur->modifyJoueur($column, $change, $columnCriteria, $criteria);

        $nameSuccess = "Joueur was updated successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function delete($column, $criteria): void
    {
        $joueur = new Joueur();
        $validation = new ValidationController();
        $joueur->deleteJoueur($column, $criteria);
        $nameSuccess = "Joueur was unsubscribed successfully!";
        $validation->tagSuccess($nameSuccess);
    }
}