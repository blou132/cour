<?php

namespace App\Controllers;

use \App\Models\Championnat;
use \App\Controllers\ValidationController;

class ChampionnatController extends Controller
{
    public function create($record): void
    {
        //$record = implode('\', \'', array_values($record));

        $championnat = new Championnat();
        $validation = new ValidationController();

        $championnat->insertChampionnat($record);
        $championnat->setDivision($record[0]);
        $championnat->setAnnee($record[1]);
        $championnat->setPays($record[2]);
        $championnat->setGenre($record[3]);
        $championnat->setProfessionnalisation($record[4]);
        $championnat->setBlason($record[5]);

        $nameSuccess = "New Championnat was created successfully!";
        $validation->tagSuccess($nameSuccess);

    }

    public function read():void
    {
        $championnat = new Championnat();
        $validation = new ValidationController();

        $championnat->list();

        $nameSuccess = "Championnat list was displayed successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function deliverPack():array
    {
        $championnat = new Championnat();
        //$validation = new ValidationController();

        return $championnat->pack();
    }

    /**
     * Chercher une championnat par ID
     */ 
    public function findByID($criteria):array
    {
        $championnat = new Championnat();

        return $championnat->findChampionnat('id', $criteria);
    }

    /**
     * Chercher une championnat par Pays
     */ 
    public function findByType($criteria):array
    {
        $championnat = new Championnat();

        return $championnat->findChampionnat('pays', $criteria);
    }

    public function update($column, $change, $columnCriteria, $criteria): void
    {
        $championnat = new Championnat();
        $validation = new ValidationController();

        $championnat->modifyChampionnat($column, $change, $columnCriteria, $criteria);

        $nameSuccess = "Championnat was updated successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function delete($column, $criteria): void
    {
        $championnat = new Championnat();
        $validation = new ValidationController();
        $championnat->deleteChampionnat($column, $criteria);
        $nameSuccess = "Championnat was unsubscribed successfully!";
        $validation->tagSuccess($nameSuccess);
    }
}