<?php

namespace App\Controllers;

use \App\Models\Equipe;
use \App\Controllers\ValidationController;

class EquipeController extends Controller
{
    public function create($record): void
    {
        //$record = implode('\', \'', array_values($record));

        $equipe = new Equipe();
        $validation = new ValidationController();

        $equipe->insertEquipe($record);
        $equipe->setNom($record[0]);
        $equipe->setVille($record[1]);
        $equipe->setStade($record[2]);
        $equipe->setIDChampionnat($record[3]);
        $equipe->setBlason($record[4]);


        $nameSuccess = "New Equipe was created successfully!";
        $validation->tagSuccess($nameSuccess);

    }

    public function read():void
    {
        $equipe = new Equipe();
        $validation = new ValidationController();

        $equipe->list();

        $nameSuccess = "Equipe list was displayed successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function deliverPack():array
    {
        $equipe = new Equipe();
        $validation = new ValidationController();

        return $equipe->pack();
    }

    /**
     * Chercher une equipe par ID
     */ 
    public function findByID($criteria):array
    {
        $equipe = new Equipe();

        return $equipe->findEquipe('id_equipe', $criteria);
    }

    /**
     * Chercher une equipe par Nom
     */ 
    public function findByType($criteria):array
    {
        $equipe = new Equipe();

        return $equipe->findEquipe('nom', $criteria);
    }

    public function update($column, $change, $columnCriteria, $criteria): void
    {
        $equipe = new Equipe();
        $validation = new ValidationController();

        $equipe->modifyEquipe($column, $change, $columnCriteria, $criteria);      

        $nameSuccess = "Equipe was updated successfully!";
        $validation->tagSuccess($nameSuccess);
    }

    public function delete($column, $criteria): void
    {
        $equipe = new Equipe();
        $validation = new ValidationController();
        $equipe->deleteEquipe($column, $criteria);        
        $nameSuccess = "Equipe was unsubscribed successfully!";
        $validation->tagSuccess($nameSuccess);
    }
}