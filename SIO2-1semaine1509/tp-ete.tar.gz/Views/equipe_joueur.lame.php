<?php

namespace App\Views;

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\JoueurController;
use App\Controllers\EquipeController;
use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Controllers\FormController;
//use App\Controllers\ValidationController;
use App\Models\Joueur;
use App\Routes\Web;

$joueur = new JoueurController();
$equipe = new EquipeController();
$html = new HtmlController();
$style = new StyleController();//<style>body{background-color:#b5cde5;};</style>
$form = new FormController();
//$validation = new ValidationController();

$deliveredEquipe = $equipe->deliverPack();
$deliveredJoueur = $joueur->deliverPack();

$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
$html->tagOpen('head');//<head>
$html->pageTitle("Joueurs et leurs Équipes" );
$html->tagClose('head');//</head>

$html->tagOpen("body");
  $menu = new Web();
    $html->tagOpen("div"); 

        echo '<h3>Afficher le Joueur et son Équipe:</h3><br/>';
        //$joueur->read();
        //echo '<h3>Afficher toutes les équipes:</h3><br/>';
        //$equipe->read();
          
        $html->tagOpen('table style="width:100%"');
        $html->tagOpen('tr');
        $html->tagOpen('th');
        echo 'Joueurs';
        $html->tagClose('th');
        $html->tagOpen('th');
        echo 'Équipes';
        $html->tagClose('th');
        $html->tagClose('tr');

        foreach($deliveredJoueur as $un_joueur)
        {
            $html->tagOpen('tr');
            $html->tagOpen('td');
                $nom = $un_joueur['nom'];
            $photo = $un_joueur['photo'];

            echo $nom;
            $html->tagImage('/storage/' . $photo, 'Un Joueur', '150', 'auto');  
            $html->tagClose('td');
            $html->tagOpen('td');
        
            foreach($deliveredEquipe as $une_equipe)
            {
                $nom = $une_equipe['nom'];
                $blason = $une_equipe['blason'];
                if ($une_equipe['id_equipe'] == $un_joueur['id_equipe'])
                {
                    echo $nom;
                    $html->tagImage('/storage/' . $blason, 'Une Equipe', '150', 'auto');  
                }

            }
            $html->tagClose('td');
            $html->tagClose('tr');
        } 
        $html->tagClose('table');

        echo '<br/>';
        $html->tagClose('div');
        $html->tagClose('body');
      $html->tagClose('html');
        