<?php

namespace App\Views;

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\ChampionnatController;
use App\Controllers\EquipeController;
use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Controllers\FormController;
use App\Controllers\ValidationController;
use App\Routes\Web;

$championnat = new ChampionnatController();
$equipe = new EquipeController();
$html = new HtmlController();
$style = new StyleController();//<style>body{background-color:#b5cde5;};</style>
$form = new FormController();
$validation = new ValidationController();


$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
$html->tagOpen('head');//<head>
$html->pageTitle("Championnats");
$html->tagClose('head');//</head>

$html->tagOpen("body");
  $menu = new Web();
    $html->tagOpen("div");

      echo '<br/>';
        echo '<h3>Créer une Championnat:</h3><br/><br/>';
          $form->openForm($_SERVER["PHP_SELF"], "POST");

          $form->tagLabel("division","Entrer la Division du Championnat:");
          $form->tagInputText("division", "division", "Division du Championnat Ici");

          $form->tagLabel("annee","Entrer l'Année du nouveau Championnat:");
          $form->tagInputText("annee", "annee", "Année du Championnat Ici");

          $form->tagLabel("pays","Entrer le Pays du nouveau Championnat:");
          $form->tagInputText("pays", "pays", "Pays du Championnat Ici");

          $form->tagLabel("genre","Entrer le Genre du nouveau Championnat:");
          $form->tagInputText("genre", "genre", "Genre du Championnat Ici");

          $form->tagLabel("professionnalisation","Entrer la Professionnalisation du nouveau Championnat:<br/>");
          $form->tagInputRadio("professionnalisation", "professionnalisation", true, true, "Vrai: ");
          $form->tagInputRadio("professionnalisation", "professionnalisation", false, false, "Faux: ");

          $form->tagLabel("blason","Entrer le Blason du nouveau Championnat:");
          $form->tagInputFile("blason", "blason");

          $form->submit("submitBtn", "Créer");
          $form->closeForm();

          if(isset($_POST['submitBtn'])) {

            if($validation->validate("division") == true && $validation->validate("pays") == true && $validation->validate("genre") == true)
            {
              $record = array($_POST['division'],$_POST['annee'],$_POST['pays'],$_POST['genre'],$_POST['professionnalisation'],$_FILES["blason"]["name"]);
                //var_dump($record);
                //var_dump($_FILES["blason"]["tmp_name"]);

                $championnat->create($record);

                $temp_file = $_FILES["blason"]["tmp_name"];
                $target_dir = "../storage/";
                $target_file = $target_dir . basename($_FILES["blason"]["name"]);

                move_uploaded_file($temp_file, $target_file);
            }
          }
            echo '<br/>';

        echo '<h3>Afficher tous les Championnats:</h3><br/>';
        $championnat->read();
        echo '<br/>';

        $delivered = $championnat->deliverPack();

        echo '<br/>';


        echo '<h3>Mettre à Jour un Championnat:</h3><br/><br/>';

        $form->openForm($_SERVER["PHP_SELF"], "POST");
        $form->tagLabel("changeChampionnat","Modifier le championnat:");

          $form->tagSelect("selectChampionnat");

          foreach($delivered as $option)
          {
            $value = $option['id_championnat'];
            $astring = implode(',', $option);
            $form->tagOptionValue("option", $value, $astring, false);
          }

          $form->closeSelect();
          echo '<br/>';

        $form->tagInputText("division", "division", "Modifier la Division Ici");
        $form->tagInputText("annee", "annee", "Modifier l'Année' Ici");
        $form->tagInputText("pays", "pays", "Modifier le Pays Ici");
        $form->tagInputText("genre", "genre", "Modifier le Genre Ici");
        $form->tagLabel("professionnalisation","Modifier la Professionnalisation du Championnat:<br/>");
        $form->tagInputRadio("professionnalisation", "professionnalisation", true, true, "Vrai: ");
        $form->tagInputRadio("professionnalisation", "professionnalisation", false, false, "Faux: ");
        $form->tagLabel("blason","Modifier le Blason du Championnat:");
        $form->tagInputFile("blason", "blason");

        $form->submit("modifyBtn", "Modifier");

        $form->closeForm();

        if(isset($_POST['modifyBtn'])) {

          if($validation->validate("division") == true && $validation->validate("pays") == true && $validation->validate("genre") == true)
          {

            $selectRecord = $_POST['selectChampionnat'];

            $changeDivision = $_POST['division'];
            $changeAnnee = $_POST['annee'];
            $changePays = $_POST['pays'];
            $changeGenre = $_POST['genre'];
            $changeProfessionnalisation = $_POST['professionnalisation'];
            $changeBlason = $_FILES['blason']['name'];

            $championnat->update("division", $changeDivision, "id_championnat", $selectRecord);
            $championnat->update("annee", $changeAnnee, "id_championnat", $selectRecord);
            $championnat->update("pays", $changePays, "id_championnat", $selectRecord);
            $championnat->update("genre", $changeGenre, "id_championnat", $selectRecord);
            $championnat->update("professionnalisation", $changeProfessionnalisation, "id_championnat", $selectRecord);
            $championnat->update("blason", $changeBlason, "id_championnat", $selectRecord);

            $temp_file = $_FILES["blason"]["tmp_name"];
            $target_dir = "../storage/";
            $target_file = $target_dir . basename($_FILES["blason"]["name"]);

            move_uploaded_file($temp_file, $target_file);
          }
        }

        echo '<h3>Supprimer un Championnat:</h3><br/><br/>';


        $form->openForm($_SERVER["PHP_SELF"], "POST");
        $form->tagLabel("deleteChampionnat","Supprimer le Championnat:");
        $form->tagSelect("deleteChampionnat");

        foreach($delivered as $option)
        {
          $value = $option['id_championnat'];
          $astring = implode(',', $option);
          $form->tagOptionValue("option", $value, $astring, false);
        }
        $form->closeSelect();

        $form->submit("deleteBtn", "Supprimer");
        $form->closeForm();

        if(isset($_POST['deleteBtn'])) {

          $id = $_POST['deleteChampionnat'];

        //  echo $id;

          $championnat->delete("id_championnat", $id);
        }

        echo '<br/>';

    $html->tagClose('div');
  $html->tagClose('body');
$html->tagClose('html');