<?php

namespace App\Views;

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\EquipeController;
use App\Controllers\ChampionnatController;
use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Controllers\FormController;
use App\Controllers\ValidationController;
use App\Routes\Web;

$equipe = new EquipeController();
$championnat = new ChampionnatController();
$html = new HtmlController();
$style = new StyleController();//<style>body{background-color:#b5cde5;};</style>
$form = new FormController();
$validation = new ValidationController();

$deliveredChampionnat = $championnat->deliverPack();

$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
$html->tagOpen('head');//<head>
$html->pageTitle("Equipes");
$html->tagClose('head');//</head>

$html->tagOpen("body");
  $menu = new Web();
    $html->tagOpen("div");

      echo '<br/>';
        echo '<h3>Créer une Equipe:</h3><br/><br/>';
          $form->openForm($_SERVER["PHP_SELF"], "POST");

          $form->tagLabel("nom","Entrer le Nom de la nouvelle Equipe:");
          $form->tagInputText("nom", "nom", "Nom de l'Equipe Ici");

          $form->tagLabel("ville","Entrer la Ville de la nouvelle Equipe:");
          $form->tagInputText("ville", "ville", "Ville de l'Equipe Ici");

          $form->tagLabel("stade","Entrer le Stade de la nouvelle Equipe:");
          $form->tagInputText("stade", "stade", "Stade de l'Equipe Ici");

          $form->tagLabel("id_championnat","Championnat de l'Equipe:");

          $form->tagSelect("id_championnat");

          foreach($deliveredChampionnat as $option)
          {
            $value = $option['id_championnat'];
            $astring = implode(',', $option);
            $form->tagOptionValue("option", $value, $astring, false);
          }
          $form->closeSelect();

          echo '<br/><br/>';

          $form->tagLabel("blason","Entrer le Blason de la nouvelle Equipe:");
          $form->tagInputFile("blason", "blason");
  
          $form->submit("submitBtn", "Créer");
          $form->closeForm();

          if(isset($_POST['submitBtn'])) {

            if($validation->validate("stade") == true)
            {
              $record = array($_POST['nom'], $_POST['ville'], $_POST['stade'], $_POST['id_championnat'], $_FILES['blason']["name"]);
                //var_dump($record);
              $equipe->create($record);

              $temp_file = $_FILES["blason"]["tmp_name"];
              $target_dir = "../storage/";
              $target_file = $target_dir . basename($_FILES["blason"]["name"]);

              move_uploaded_file($temp_file, $target_file);
            }
          }
            echo '<br/>';

        echo '<h3>Afficher toutes les Equipes:</h3><br/>';
        $equipe->read();
        echo '<br/>';

        $delivered = $equipe->deliverPack();

        echo '<br/>';

        echo '<h3>Mettre à Jour une Equipe:</h3><br/><br/>';

        $form->openForm($_SERVER["PHP_SELF"], "POST");
        $form->tagLabel("changeEquipe","Modifier la Equipe:");

          $form->tagSelect("selectEquipe");

          foreach($delivered as $option)
          {
            $value = $option['id_equipe'];
            $astring = implode(',', $option);
            $form->tagOptionValue("option", $value, $astring, false);
          }
  
          $form->closeSelect();
          echo '<br/>';
  
        $form->tagInputText("nom", "nom", "Modifier le Nom de l'a 'Equipe Ici");
        $form->tagInputText("ville", "ville", "Modifier la Ville de l'a 'Equipe Ici");
        $form->tagInputText("stade", "stade", placeholder: "Modifier le Stade de l'a 'Equipe Ici");

        $form->tagLabel("id_championnat","Modifier le Championnat de l'Equipe:");

          $form->tagSelect("id_championnat");

          foreach($deliveredChampionnat as $option)
          {
            $value = $option['id_championnat'];
            $astring = implode(',', $option);
            $form->tagOptionValue("option", $value, $astring, false);
          }
          $form->closeSelect();

        $form->tagLabel("blason","Modifier le Blason de la nouvelle Equipe:");
        $form->tagInputFile("blason", "blason");

        $form->submit("modifyBtn", "Modifier");
        $form->closeForm();      
  
        if(isset($_POST['modifyBtn'])) {
  
          if($validation->validate("stade") == true)
          {
  
            $selectRecord =$_POST['selectEquipe'];  
  
            $changeNom = $_POST['nom'];  
            $changeVille = $_POST['ville'];
            $changeStade = $_POST['stade'];
            $changeChampionnat = $_POST['id_championnat'];
            $changeBlason = $_FILES['blason']['name'];

            $equipe->update("nom", $changeNom, "id_equipe", $selectRecord);
            $equipe->update("ville", $changeVille, "id_equipe", $selectRecord);
            $equipe->update("stade",$changeStade, "id_equipe", $selectRecord);
            $equipe->update("id_championnat", $changeChampionnat, "id_equipe", $selectRecord);
            $equipe->update("blason", $changeBlason, "id_equipe", $selectRecord);

            $temp_file = $_FILES["blason"]["tmp_name"];
            $target_dir = "../storage/";
            $target_file = $target_dir . basename($_FILES["blason"]["name"]);

            move_uploaded_file($temp_file, $target_file); 
          }
        }

        echo '<h3>Supprimer une Equipe:</h3><br/><br/>';


        $form->openForm($_SERVER["PHP_SELF"], "POST");
        $form->tagLabel("deleteEquipe","Supprimer la Equipe:");
        $form->tagSelect("deleteEquipe");

        foreach($delivered as $option)
        {
          $value = $option['id_equipe'];
          $astring = implode(',', $option);
          $form->tagOptionValue("option", $value, $astring, false);
        }
        $form->closeSelect();
        
        $form->submit("deleteBtn", "Supprimer");
        $form->closeForm();
        
        if(isset($_POST['deleteBtn'])) {

          $id = $_POST['deleteEquipe'];

        //  echo $id;

          $equipe->delete("id_equipe", $id);
        }
      
        echo '<br/>';

    $html->tagClose('div');
  $html->tagClose('body');
$html->tagClose('html');
