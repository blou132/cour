<?php

namespace App\Views;

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\JoueurController;
use App\Controllers\EquipeController;
use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Controllers\FormController;
use App\Controllers\ValidationController;
use App\Routes\Web;

$joueur = new JoueurController();
$equipe = new EquipeController();
$html = new HtmlController();
$style = new StyleController();//<style>body{background-color:#b5cde5;};</style>
$form = new FormController();
$validation = new ValidationController();

$deliveredEquipe = $equipe->deliverPack();

$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
$html->tagOpen('head');//<head>
$html->pageTitle("Joueurs");
$html->tagClose('head');//</head>

$html->tagOpen("body");
  $menu = new Web();
    $html->tagOpen("div");

        echo '<br/>';
        echo '<h3>Créer un Joueur:</h3><br/><br/>';
          $form->openForm($_SERVER["PHP_SELF"], "POST");

          $form->tagLabel("position","Entrer la Position du Joueur:");
          $form->tagInputText("position", "position", "Position du Joueur Ici");

          $form->tagLabel("numero","Entrer le Numero du Joueur:");
          $form->tagInputText("numero", "numero", "Numero du Joueur Ici");

          $form->tagLabel("nom","Entrer le Nom du Joueur:");
          $form->tagInputText("nom", "nom", "Nom du Joueur Ici");

          $form->tagLabel("nationalite","Entrer la Nationalite du Joueur:");
          $form->tagInputText("nationalite", "nationalite", "Nationalite du Joueur Ici");

          $form->tagLabel("age","Entrer l'Age du Joueur:");
          $form->tagInputText("age", "age", "Age du Joueur Ici");

          $form->tagLabel("id_equipe","Equipe du Joueur:");

          $form->tagSelect("id_equipe");

          foreach($deliveredEquipe as $option)
          {
            $value = $option['id_equipe'];
            $astring = implode(',', $option);
            $form->tagOptionValue("option", $value, $astring, false);
          }
          $form->closeSelect();

          $form->tagLabel("photo","Entrer la Photo du Joueur:");
          $form->tagInputFile("photo", "photo");

          echo '<br/><br/>';

          $form->submit("submitBtn", "Créer");
          $form->closeForm();

          if(isset($_POST['submitBtn'])) {

            if($validation->validate("numero") == true && $validation->validate("nom") == true)
            {
              $record = array($_POST['position'],$_POST['numero'],$_POST['nom'],$_POST['nationalite'],$_POST['age'],$_POST['id_equipe'],$_FILES["photo"]["name"]);

              //var_dump($record);

              $joueur->create($record);

              $temp_file = $_FILES["photo"]["tmp_name"];
              $target_dir = "../storage/";
              $target_file = $target_dir . basename($_FILES["photo"]["name"]);

              move_uploaded_file($temp_file, $target_file);
            }
          }
            echo '<br/>';

        echo '<h3>Afficher toutes les joueurs:</h3><br/>';
        $joueur->read();
        echo '<br/>';


        $delivered = $joueur->deliverPack();

        echo '<br/>';
  
        echo '<h3>Mettre à Jour un Joueur:</h3><br/><br/>';

          $form->openForm($_SERVER["PHP_SELF"], "POST");
          $form->tagLabel("changeJoueur","Modifier le joueur:");

            $form->tagSelect("selectJoueur");

            foreach($delivered as $option)
            {
              $value = $option['id_joueur'];
              $astring = implode(',', $option);
              $form->tagOptionValue("option", $value, $astring, false);
            }

            $form->closeSelect();
            echo '<br/>';

            $form->tagInputText("position", "position", "Modifier la Position Ici");
            $form->tagInputText("numero", "numero", "Modifier le Numero Ici");
            $form->tagInputText("nom", "nom", "Modifier le Nom Ici");
            $form->tagInputText("nationalite", "nationalite", "Modifier la Nationalité Ici");
            $form->tagInputText("age", "age", "Modifier l'Age Ici");
            $form->tagLabel("id_equipe","Modifier l'Equipe Ici:");
            $form->tagSelect("id_equipe");
    
            foreach($deliveredEquipe as $option)
            {
              $value = $option['id_equipe'];
              $astring = implode(',', $option);
              $form->tagOptionValue("option", $value, $astring, false);
            }
            $form->closeSelect();
            echo '<br/>';
            $form->tagLabel("photo","Modifier la Photo du Joueur:");
            $form->tagInputFile("photo", "photo");
    
            $form->submit("modifyBtn", "Modifier");
          $form->closeForm();      

          if(isset($_POST['modifyBtn'])) {

            if($validation->validate("numero") == true && $validation->validate("nom") == true)
            {
    
              $selectRecord =$_POST['selectJoueur'];
    
              $changePosition = $_POST['position'];  
              $changeNumero = $_POST['numero'];  
              $changeNom = $_POST['nom'];  
              $changeNationalite = $_POST['nationalite'];
              $changeAge = $_POST['age'];
              $changeIDEquipe = $_POST['id_equipe'];  
              $changePhoto = $_FILES['photo']['name'];
  
              $joueur->update("position", $changePosition, "id_joueur", $selectRecord);
              $joueur->update("numero", $changeNumero, "id_joueur", $selectRecord);
              $joueur->update("nom", $changeNom, "id_joueur", $selectRecord);
              $joueur->update("nationalite", $changeNationalite, "id_joueur", $selectRecord);
              $joueur->update("age", $changeAge, "id_joueur", $selectRecord);
              $joueur->update("id_equipe", $changeIDEquipe, "id_joueur", $selectRecord);
              $joueur->update("photo", $changePhoto, "id_joueur", $selectRecord);
  
              $temp_file = $_FILES["photo"]["tmp_name"];
              $target_dir = "../storage/";
              $target_file = $target_dir . basename($_FILES["photo"]["name"]);
              
              move_uploaded_file($temp_file, $target_file); 
            }  
          }
            echo '<br/>';

            echo '<h3>Supprimer un Joueur:</h3><br/><br/>';

            $form->openForm($_SERVER["PHP_SELF"], "POST");
            $form->tagLabel("deleteJoueur","Supprimer le joueur:");
            $form->tagSelect("deleteJoueur");

            foreach($delivered as $option)
            {
              $value = $option['id_joueur'];
              $astring = implode(',', $option);
              $form->tagOptionValue("option", $value, $astring, false);
            }

            $form->closeSelect();
            $form->submit("deleteBtn", "Supprimer");
            $form->closeForm();
  
            if(isset($_POST['deleteBtn'])) {
              $id = $_POST['deleteJoueur'];
              //var_dump($id);
              $joueur->delete("id_joueur", $id);
            }
          
            echo '<br/>';
          $html->tagClose('div');
        $html->tagClose('body');
      $html->tagClose('html');
        