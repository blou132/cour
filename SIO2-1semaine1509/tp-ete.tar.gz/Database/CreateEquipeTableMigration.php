<?php

namespace App\Database;

include_once( __DIR__ . '/Database.php');

 $db = new Database();
    $db->exec('DROP TABLE equipes');
    $db->exec('CREATE TABLE equipes (
        id_equipe INTEGER PRIMARY KEY AUTOINCREMENT,
        nom VARCHAR NOT NULL ,
        ville VARCHAR NOT NULL ,
        stade VARCHAR NOT NULL ,
        id_championnat INTEGER NOT NULL ,
        blason VARCHAR NOT NULL,
        FOREIGN KEY(id_championnat) REFERENCES championnats(id_championnat) ON DELETE CASCADE
    )');