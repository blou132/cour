<?php

namespace App\Database;

include_once( __DIR__ . '/Database.php');

 $db = new Database();

    $db->exec('DROP TABLE joueurs');
    $db->exec('CREATE TABLE joueurs (
        id_joueur INTEGER PRIMARY KEY AUTOINCREMENT,
        position VARCHAR NOT NULL ,
        numero INTEGER NOT NULL ,
        nom VARCHAR NOT NULL ,
        nationalite VARCHAR NOT NULL ,
        age INTEGER NOT NULL ,
        id_equipe INTEGER NOT NULL ,
        photo VARCHAR NOT NULL ,
        FOREIGN KEY(id_equipe) REFERENCES equipes(id_equipe) ON DELETE CASCADE
    )');