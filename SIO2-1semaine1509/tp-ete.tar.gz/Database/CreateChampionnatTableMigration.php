<?php

namespace App\Database;

include_once( __DIR__ . '/Database.php');

 $db = new Database();
    $db->exec('DROP TABLE championnats');
    $db->exec('CREATE TABLE championnats (
        id_championnat INTEGER PRIMARY KEY AUTOINCREMENT,
        division VARCHAR NOT NULL ,
        annee INTEGER NOT NULL ,
        pays VARCHAR NOT NULL ,
        genre VARCHAR NOT NULL ,
        professionnalisation BOOLEAN NOT NULL,
        blason VARCHAR NOT NULL
    )');