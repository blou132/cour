<?php

namespace App;

require_once( __DIR__ . '/Autoload.php');

use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Routes\Web;

$html = new HtmlController();
$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
  $html->tagOpen('head');//<head>
    $html->pageTitle("Accueil");
    $style = new StyleController();
  $html->tagClose('head');//</head>
  $html->tagOpen('body');
    $menu = new Web();
    $html->tagImage('./accueil.png', 'Football', '828', '552');  
  $html->tagClose('body');
$html->tagClose('html');