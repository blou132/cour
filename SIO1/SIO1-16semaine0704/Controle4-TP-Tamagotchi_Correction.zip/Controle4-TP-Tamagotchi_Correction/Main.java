import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        Tamagotchi monChat = new Chat("Minou");
        Tamagotchi monChien = new Chien("Rex");

        monChat.afficherEtat();
        System.out.println("-------------------");
        monChien.afficherEtat();
        System.out.println("-------------------\n");

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Nourrir le chat");
            System.out.println("2. Jouer avec le chat");
            System.out.println("3. Faire dormir le chat");
            System.out.println("4. Nourrir le chien");
            System.out.println("5. Jouer avec le chien");
            System.out.println("6. Faire dormir le chien");
            System.out.println("7. Afficher tout");
            System.out.print("Choisissez une option: ");

            int choix = scanner.nextInt();
            scanner.nextLine(); // Consommer le retour à la ligne

            switch (choix) {
                case 1:
                    GestionTamagotchi.nourrir(monChat);
                    Chrono.calculerEtat(monChat, startTime);
                    monChat.afficherEtat();    
                    System.out.println("-------------------\n");
                    break;
                case 2:
                    GestionTamagotchi.jouerAvec(monChat);
                    Chrono.calculerEtat(monChat, startTime);
                    monChat.afficherEtat();    
                    System.out.println("-------------------\n");
                    break;
                case 3:
                    GestionTamagotchi.faireDormir(monChat);
                    Chrono.calculerEtat(monChat, startTime);
                    monChat.afficherEtat();    
                    System.out.println("-------------------\n");
                    break;
                case 4:
                    GestionTamagotchi.nourrir(monChien);
                    Chrono.calculerEtat(monChien, startTime);
                    monChien.afficherEtat();    
                    System.out.println("-------------------\n");
                    break;
                case 5:
                    GestionTamagotchi.jouerAvec(monChien);
                    Chrono.calculerEtat(monChien, startTime);
                    monChien.afficherEtat();    
                    System.out.println("-------------------\n");
                    break;
                case 6:
                    GestionTamagotchi.faireDormir(monChien);
                    Chrono.calculerEtat(monChien, startTime);
                    monChien.afficherEtat();    
                    System.out.println("-------------------\n");
                    break;
                case 7:
                    Chrono.calculerEtat(monChat, startTime);
                    Chrono.calculerEtat(monChien, startTime);
                    monChat.afficherEtat();
                    System.out.println("-------------------");
                    monChien.afficherEtat();      
                    System.out.println("-------------------\n");  
                    break;
                default:
                    System.out.println("Option invalide !");
            }
        }
    }
}
