public class Chien extends Tamagotchi implements ComportementManger, ComportementJouer {

    public Chien(String nom) {
        super(nom);
    }

    @Override
    public void manger() {
        System.out.println(getNom() + " mange des croquettes.");
        setNiveauFaim(getNiveauFaim() - 15);
        if (getNiveauFaim() < 0) setNiveauFaim(0);
    }

    @Override
    public void jouer() {
        System.out.println(getNom() + " joue à la balle.");
        setNiveauAmour(getNiveauAmour() + 15);
        if (getNiveauAmour() > 100) setNiveauAmour(100);
    }

    @Override
    public void dormir() {
        System.out.println(getNom() + " dort profondément.");
        setNiveauSante(getNiveauSante() + 30);
        if (getNiveauSante() > 100) setNiveauSante(100);
    }
}

