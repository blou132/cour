public class GestionTamagotchi {
    public static void nourrir(Tamagotchi tamagotchi) {
        tamagotchi.manger();
    }

    public static void jouerAvec(Tamagotchi tamagotchi) {
        tamagotchi.jouer();
    }

    public static void faireDormir(Tamagotchi tamagotchi) {
        tamagotchi.dormir();
    }
}

