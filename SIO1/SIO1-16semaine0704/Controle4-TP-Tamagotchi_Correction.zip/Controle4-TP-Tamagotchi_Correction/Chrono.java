import java.util.Date; 

public class Chrono{

    public static void calculerEtat(Tamagotchi tamagotchi, long startTime) {

        int elapsedTime = (int)((new Date()).getTime() - startTime)/60000;

        System.out.println("Temps Ecoulé: " + elapsedTime);
        tamagotchi.setNiveauFaim(tamagotchi.getNiveauFaim() + elapsedTime);
        if (tamagotchi.getNiveauFaim() > 100) tamagotchi.setNiveauFaim(100);

        tamagotchi.setNiveauAmour(tamagotchi.getNiveauAmour() - elapsedTime);
        if (tamagotchi.getNiveauAmour() < 0) tamagotchi.setNiveauAmour(0);

        tamagotchi.setNiveauSante(tamagotchi.getNiveauSante() - elapsedTime);
        if (tamagotchi.getNiveauSante() < 0) tamagotchi.setNiveauSante(0);
    }
}