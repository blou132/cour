public abstract class Tamagotchi {
    private String nom;
    private int niveauSante;
    private int niveauFaim;
    private int niveauAmour;

    public Tamagotchi(String nom) {
        this.nom = nom;
        this.niveauSante = 100;
        this.niveauFaim = 0;
        this.niveauAmour = 100;
    }

    public String getNom() {
        return nom;
    }

    public int getNiveauSante() {
        return niveauSante;
    }

    public int getNiveauFaim() {
        return niveauFaim;
    }

    public int getNiveauAmour() {
        return niveauAmour;
    }

    public void setNiveauSante(int niveauSante) {
        this.niveauSante = niveauSante;
    }

    public void setNiveauFaim(int niveauFaim) {
        this.niveauFaim = niveauFaim;
    }

    public void setNiveauAmour(int niveauAmour) {
        this.niveauAmour = niveauAmour;
    }

    // Méthodes abstraites
    public abstract void manger();
    public abstract void jouer();
    public abstract void dormir();

    public void afficherEtat() {
        System.out.println("Nom: " + nom);
        System.out.println("Santé: " + niveauSante);
        System.out.println("Faim: " + niveauFaim);
        System.out.println("Amour: " + niveauAmour);
    }
}
