public class Chat extends Tamagotchi implements ComportementManger, ComportementJouer {

    public Chat(String nom) {
        super(nom);
    }

    @Override
    public void manger() {
        System.out.println(getNom() + " mange des croquettes.");
        setNiveauFaim(getNiveauFaim() - 20);
        if (getNiveauFaim() < 0) setNiveauFaim(0);
    }

    @Override
    public void jouer() {
        System.out.println(getNom() + " joue avec une balle.");
        setNiveauAmour(getNiveauAmour() + 10);
        if (getNiveauAmour() > 100) setNiveauAmour(100);
    }

    @Override
    public void dormir() {
        System.out.println(getNom() + " dort.");
        setNiveauSante(getNiveauSante() + 20);
        if (getNiveauSante() > 100) setNiveauSante(100);
    }
}

