public interface ComportementJouer {
    void jouer();
}

