public interface ComportementManger {
    void manger();
}
