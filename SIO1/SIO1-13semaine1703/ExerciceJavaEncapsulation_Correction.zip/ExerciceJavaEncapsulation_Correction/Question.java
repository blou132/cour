public class Question {
    private String questionText;
    private String[] choices;
    private char correctAnswer;

    public Question(String questionText, String[] choices, char correctAnswer) {
        this.questionText = questionText;
        this.choices = choices;
        this.correctAnswer = correctAnswer;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String[] getChoices() {
        return choices;
    }

    public char getCorrectAnswer() {
        return correctAnswer;
    }

    public boolean checkAnswer(char answer) {
        return answer == correctAnswer;
    }
}
