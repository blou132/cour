import java.util.Scanner;

public class Quiz {

    private Question question;
    private Question [] questions;
    private int score;
    int nextIndex = 0;
    
    public Quiz() {
        questions = new Question[3];
        score = 0;
    }

    public void addQuestion(Question question) {
        questions[nextIndex] = question;
        ++nextIndex;
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);

        for (Question question : questions) {
            System.out.println(question.getQuestionText());
            String[] choices = question.getChoices();
            for (String choice : choices) {
                System.out.println(choice);
            }
            System.out.print("Votre réponse (A/B/C/D) : ");
            char userAnswer = scanner.next().charAt(0);
            userAnswer = Character.toUpperCase(userAnswer);

            if (question.checkAnswer(userAnswer)) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Incorrect. La bonne réponse était " + question.getCorrectAnswer() + ".");
            }
            System.out.println();
        }

        System.out.println("Vous avez obtenu " + score + " sur " + questions.length + ".");
        System.out.println("Merci d'avoir participé au QCM!");
        scanner.close();
    }
}
