public class Main {
    public static void main(String[] args) {
        Quiz quiz = new Quiz();

        String[] choices1 = {"A) Paris", "B) Londres", "C) Berlin", "D) Madrid"};
        String[] choices2 = {"A) Atlantique", "B) Pacifique", "C) Indien", "D) Arctique"};
        String[] choices3 = {"A) Victor Hugo", "B) Charles Dickens", "C) Mark Twain", "D) Ernest Hemingway"};

        quiz.addQuestion(new Question("Quelle est la capitale de la France?", choices1, 'A'));
        quiz.addQuestion(new Question("Quel est le plus grand océan de la Terre?", choices2, 'B'));
        quiz.addQuestion(new Question("Qui a écrit 'Les Misérables'?", choices3, 'A'));

        quiz.start();
    }
}

