<?php

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\HtmlController;
use App\Controllers\StyleController;

$html = new HtmlController();
$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
  $html->tagOpen('head');//<head>
    $html->pageTitle(title: "Accueil");
    $style = new StyleController();
  $html->tagClose('head');//</head>
  $html->tagOpen("body");
  ?>
  <!--
    Ce Href sera supprimé une fois que le menu sera implémenté dans 'Routes':
  -->

    <a href="http://localhost:8000/user.lame.php">go to User</a>
  <?php
  $html->tagClose("body");
$html->tagClose("html");