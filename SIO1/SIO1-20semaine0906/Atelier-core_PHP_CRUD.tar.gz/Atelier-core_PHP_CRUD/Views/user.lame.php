<?php

require_once( __DIR__ . '/../Autoload.php');

use App\Controllers\UserController;
use App\Controllers\HtmlController;
use App\Controllers\StyleController;
use App\Controllers\FormController;

$user = new UserController();
$html = new HtmlController();
$style = new StyleController();//<style>body{background-color:#b5cde5;};</style>
$form = new FormController();
$html->tagOpen('!DOCTYPE html');
$html->tagOpen('html');
$html->tagOpen('head');//<head>
$html->pageTitle("Utilisateurs");
$html->tagClose('head');//</head>

$html->tagOpen("body");

    $html->tagOpen("div");
    echo '<br/>';
    echo '<h3>Créer un Utilisateur:</h3><br/><br/>';
      $form->openForm($_SERVER["PHP_SELF"], "POST");

      $form->tagLabel("nom","Entrer le nom du nouvel utilisateur:");
      $form->tagInputText("nom", "nom", "Nom de l'Utilisateur Ici");

      $form->tagLabel("pseudo","Entrer le pseudo de l'utilisateur:");
      $form->tagInputText("pseudo", "pseudo", "Pseudo de l'Utilisateur Ici");

      $form->tagLabel("email","Entrer l'adresse email de l'utilisateur:");
      $form->tagInputText("email", "email", "Email Utilisateur Ici");

      $form->tagLabel("password","Entrer le mot de passe utilisateur:");
      $form->tagInputText("password", "password", "Mot de passe Utilisateur Ici");

      $form->submit("submitBtn", "Créer");
      $form->closeForm();

      if(isset($_POST['submitBtn'])) {

        $record = array($_POST['nom'],$_POST['pseudo'],$_POST['email'],$_POST['password']);
        //var_dump($record);
        $user->create($record);
      }
    echo '<br/>';

    echo '<h3>Afficher tous les utilisateurs:</h3><br/>';
    $user->read();
    echo '<br/>';


    /*
     La prochaine étape sera de créer un formulaire de mise à jour. vous aurez pour cela besoin de "$delivered" pour
     sélectionner l'utilisateur à mettre à jour avec un FormController "select ... option"

     Je vous laisse le soin de chercher comment opérer ces modification grâce au formulaire.

     La dernière fonctionnalité du CRUD "delete" est assez similaire en soi car on doit construire un formulaire qui
     selectionne l'instance d'objet à supprimer
    */

    echo '<br/>';

        echo '<br/>';
      $html->tagClose('div');
    $html->tagClose('body');
  $html->tagClose('html');

  //A ce stade vous, devriez être capable de faire dans vscode "PHP Server: serve project" en cliquant à droite sur
  // cette page si vous avez installé l'extension "PHP Server" afin d'afficher la page dans le navigateur.