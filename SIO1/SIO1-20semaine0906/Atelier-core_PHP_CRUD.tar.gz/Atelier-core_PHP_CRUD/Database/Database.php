<?php

namespace App\Database;

use SQLite3;

/**
* Simple example of extending the SQLite3 class and declaring __construct
* , then using the open method to initialize the DB.
*/
class Database extends SQLite3
{
    function __construct()
    {
        $this->open( __DIR__ . '/mysqlite.db');
        $this->query("PRAGMA foreign_keys = ON");
    }
}
