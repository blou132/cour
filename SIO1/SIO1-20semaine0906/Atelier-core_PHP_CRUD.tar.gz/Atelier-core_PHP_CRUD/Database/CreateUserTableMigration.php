<?php

namespace App\Database;

include_once( __DIR__ . '/Database.php');

 $db = new Database();

    $db->exec('CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom STRING NOT NULL,
        pseudo STRING UNIQUE NOT NULL,
        email STRING UNIQUE NOT NULL,
        password STRING NOT NULL
    )');