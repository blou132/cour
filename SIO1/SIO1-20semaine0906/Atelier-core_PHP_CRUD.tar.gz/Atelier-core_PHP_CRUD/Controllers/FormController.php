<?php

namespace App\Controllers;

class FormController extends Controller
{
    public function openForm(string $action, string $method): void
    {
        // This function prevents XSS attacks: http://localhost:3000/Views/user.lame.php/%22%3E%3Cscript%3Ealert('hacked')%3C/script%3E
        $validated = htmlspecialchars($action);

        echo "<form action=\"$validated\" method=\"$method\">";
    }

    public function closeForm(): void
    {
        echo "</form>";
    }

    public function tagLabel(string $for, string $content): void
    {
        echo "<label for=\"$for\">$content</label>";
    }

    public function tagInputText(string $name_value, string $id_value, string $placeholder): void
    {
        echo "<input type=\"text\" name=\"$name_value\" id=\"$id_value\" placeholder=\"$placeholder\"/><br/><br/>";
    }

    public function tagInputRadio(string $name_value, string $id_value, bool $value, bool $checked, string $content): void
    {
        if($checked == true)
            echo "<input type=\"radio\" name=\"$name_value\" id=\"$id_value\" value=\"$value\" checked/>$content<br/>";
        else
            echo "<input type=\"radio\" name=\"$name_value\" id=\"$id_value\" value=\"$value\"/>$content<br/>";
    }

    public function tagInputCheckbox(string $name_value, string $id_value, string $value, bool $checked, string $content): void
    {
        if($checked == true)
            echo "<input type=\"checkbox\" name=\"$name_value\" id=\"$id_value\" value=\"$value\" checked/>$content<br/><br/>";
        else
            echo "<input type=\"checkbox\" name=\"$name_value\" id=\"$id_value\" value=\"$value\"/>$content<br/><br/>";            
    }

    public function tagInputRange(string $name_value, string $id_value, string $min, string $max, string $step, string $value): void
    {
        echo "<input type=\"range\" name=\"$name_value\" id=\"$id_value\" min=\"$min\" max=\"$max\" step=\"$step\" value=\"$value\"/><br/><br/>";
    }

    public function tagSelect(string $name_value): void
    {
        echo "<select name=\"$name_value\">";
    }

    public function closeSelect(): void
    {
        echo "</select>";
    }

    public function tagOption(string $name_value, string $content, bool $selected): void
    {
        if($selected == true)
            echo "<option name=\"$name_value\" selected>$content</option>";
        else
            echo "<option name=\"$name_value\">$content</option>";
    }

    public function tagOptionValue(string $name_value, string $value, string $content, bool $selected): void
    {
        if($selected == true)
            echo "<option name=\"$name_value\" value=\"$value\" selected>$content</option>";
        else
            echo "<option name=\"$name_value\" value=\"$value\">$content</option>";
    }

    public function submit(string $name_value, string $value): void
    {
        echo "<input type=\"submit\" name=\"$name_value\" value=\"$value\">";
    }
}