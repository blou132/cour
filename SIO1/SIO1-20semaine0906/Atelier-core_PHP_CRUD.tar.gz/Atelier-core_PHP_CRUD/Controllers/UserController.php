<?php

namespace App\Controllers;

use \App\Models\User;
use \App\Controllers\HtmlController;


class UserController extends Controller
{
    public function create($record): void
    {
        //$record = implode('\', \'', array_values($record));

        $user = new User();
        $html = new HtmlController();

        $user->insertUser($record);
        $user->setNom($record[0]);
        $user->setPseudo($record[1]);
        $user->setEmail($record[2]);
        $user->setPassword($record[3]);

        $nameSuccess = "New user was created successfully!";
        $html->tagSuccess($nameSuccess);
    }

    public function read(): void
    {
        $user = new User();
        $html = new htmlController();

        $user->list();
        $nameSuccess = "User list  was displayed successfully!";
        $html->tagSuccess($nameSuccess);
    }

    public function deliverPack():array
    {
        $user = new User();

        return $user->pack();
    }

    // La prochaine étape sera de créer un controller de mise à jour.
    // Je vous laisse le soin de chercher comment opérer ces modification grâce au formulaire.
    // La dernière fonctionnalité du CRUD "delete" est assez similaire en soi car on doit construire un formulaire qui
    // selectionne l'instance d'objet à supprimer.
    // Pour se faire, nous utiliserons des méthodes récupérant les méthodes existantes du modèle User, findByID(), 
    // update() et delete().
    // Je vous laisse libre du choix d'implémentation ...
}