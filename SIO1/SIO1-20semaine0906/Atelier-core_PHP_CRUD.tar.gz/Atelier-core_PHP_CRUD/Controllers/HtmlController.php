<?php

namespace App\Controllers;

class HtmlController extends Controller
{
    public function pageTitle(string $title): void
    {
        echo "<title>$title</title>";
    }

    public function tagOpen(string $tag): void
    {
        echo "<$tag>";
    }

    public function tagClose(string $tag): void
    {
        echo "</$tag>";
    }

    public function URLlink(string $path, string $content): void
    {
        echo "<li><a href=\"$path\">$content</a></li>";
    }

    function tagError(string $nameErr): void
    {
        echo "<span class=\"error\">$nameErr</span>";
    }

    function tagSuccess(string $nameSuccess): void
    {
        echo "<span class=\"success\">$nameSuccess</span>";
    }
}
