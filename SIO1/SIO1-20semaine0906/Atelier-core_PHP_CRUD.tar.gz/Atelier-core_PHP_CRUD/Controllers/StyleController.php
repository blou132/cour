<?php 

namespace App\Controllers;

class StyleController extends Controller{


    public function __construct(){

        echo "
        <style>
        html{
            display: flex;
            justify-content: center;
        };
        </style>";
        echo "
        <style>
        .error{
            color: #FF0000;
        };
        </style>";
        echo "
        <style>
        .success{
            color: #00FF00;
        };
        </style>";
        echo "
        <style>
        .bleu{
            color: #0000FF;
        };
        </style>";

    }
}