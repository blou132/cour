<?php

namespace App\Models;

use App\Database\Database;

define("USERS", "users");

class User extends Model
{
	private string $nom;
	private string $pseudo;
	private string $email;
	private string $password;


    /**
     * Constructeur Vide
     */
    public function __construct()
    {
        //Empty constructor instead
    }

    /**
     * Afficher tous les utilisateurs
     */
    public function list()
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        $this->all(USERS, $attributes);
    }

    /**
     * Mettre à disposition les utilisateurs dans une array
     */
    public function pack():array
    {
        $attributes = get_class_vars(get_class($this));
        // echo var_dump($attributes);
        return $this->packAll(USERS, $attributes);
    }


    /**
     * Insérer un utilisateur
     */
    public function insertUser($records)
    {
        $attributes = get_class_vars(get_class($this));
        $this->insert(USERS, $attributes, $records);
    }

// Pour compléter le CRUD, vous aurez besoin de méthodes à récupérer dans UserController,
// quelquechose comme:

// findUser($column, $criteria)
// modifyUser($column, $change, $columnCriteria, $criteria)
// et unsubscribe($column, $criteria)

    /**
     * Obtenir la valeur du Nom
     */
	public function getNom(): string
	{
		return $this->nom;
	}

    /**
     * Obtenir la valeur du Pseudo
     */
	public function getPseudo(): string
	{
		return $this->pseudo;
	}

    /**
     * Obtenir la valeur de l'Email
     */
	public function getEmail(): string
	{
		return $this->email;
	}

    /**
     * Obtenir la valeur du Mot de Passe
     */
	public function getPassword(): string
	{
		return $this->password;
	}

    /**
     * Configurer la valeur du Nom
     */
	public function setNom($nom): void
	{
		$this->nom = $nom;
	}

   /**
     * Configurer la valeur du Pseudo
     */
	public function setPseudo($pseudo): void
	{
		$this->pseudo = $pseudo;
	}

    /**
     * Configurer la valeur de l'Email
     */
	public function setEmail($email): void
	{
		$this->email = $email;
	}

   /**
     * Configurer la valeur du Mot de Passe
     */
	public function setPassword($password): void
	{
		$this->password = password_hash($password, PASSWORD_DEFAULT);
	}
}

