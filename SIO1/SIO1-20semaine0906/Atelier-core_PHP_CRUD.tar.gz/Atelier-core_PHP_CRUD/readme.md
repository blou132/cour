# solution core PHP Orientée Objet avec Create et Read avec connexion à SQLite

## Arborescence du projet:

/Atelier-core_PHP_CRUD/
│
├── Controllers/
│   ├── Controller.php
│   ├── FormCOntroller.php
│   ├── HtmlController.php
│   ├── StyleController.php
│   └── UserController.php
├── Database/
│   ├── CreateUserTableMigration.php
│   ├── Database.php
│   └── mysqlite.db
├── Models/
│   ├── Model.php
│   └── User.php
├── Routes/
├── Views/
│   ├── user.lame.php
│   └── index.php
├── Autoload.php     ← Autoloader reconfiguré

## Pour lancer le projet:

php -S localhost:8000 -t Views

